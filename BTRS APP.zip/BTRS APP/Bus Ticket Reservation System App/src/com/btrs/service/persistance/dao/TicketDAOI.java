package com.btrs.service.persistance.dao;

import java.sql.SQLException;
import java.util.List;

import com.btrs.model.entity.BusTO;
import com.btrs.model.entity.TicketTO;
import com.btrs.service.exception.MVCApplicationException;

public interface TicketDAOI 
{


	public boolean verifyBookingID(String customerID) throws MVCApplicationException;
	public TicketTO getBookingDetails(TicketTO ticketTO) throws SQLException, MVCApplicationException;
	public TicketTO getJourneyDate(TicketTO jDate) throws  MVCApplicationException;
	public List<TicketTO> getSchedule(TicketTO routeInfo) throws  MVCApplicationException;
	public List<String> getTransportationDetails(TicketTO ticketTO) throws  MVCApplicationException;
	public List<BusTO> getBusDetails(String scheduleId) throws  MVCApplicationException;
	public List<String> getSeatsDetails(String scheduleId) throws MVCApplicationException;
	public List<String> getScheduleTime(String scheduleId) throws MVCApplicationException;
	public List<String> getCostDetails(TicketTO data) throws  MVCApplicationException;
	public String generateTicketID(String id) throws  MVCApplicationException;
	public String bookTickets(TicketTO ticketTO) throws  MVCApplicationException;
	public TicketTO viewTicket(String ticketID) throws  MVCApplicationException;
	
	
	/*public List<TicketTO> getCustomerTickets(String customerID) throws SQLException;

	public boolean cancelReservation(String ticketID) throws SQLException;*/
	
}
