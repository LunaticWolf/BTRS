package com.btrs.service.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.btrs.model.entity.UserTO;
import com.btrs.service.constants.QueryConstants;
import com.btrs.service.exception.MVCApplicationException;
import com.btrs.service.util.DBConnection;
import com.btrs.service.util.DBConnectionI;




public class UserDAO implements UserDAOI
{
	
	static Connection myConn = null;
	static PreparedStatement preparedStatement = null;
	static ResultSet myRslt = null;
	
	
	@Override
	public boolean verifyUserAuthentication(UserTO userTO) throws MVCApplicationException 
	{
		
			boolean verifyAuthentication = false;
		
			DBConnectionI db = new DBConnection();
			
			
			try
			{
				myConn = db.getMySQLConnection();
				preparedStatement = myConn.prepareStatement(QueryConstants.VERIFY_LOGIN);
				preparedStatement.setString(1, userTO.getUserId());
			
				myRslt = preparedStatement.executeQuery();
				if(myRslt.next())
				{
					
					String password = myRslt.getString("pass_word");
					if(password.equals(userTO.getPassword()))
					{
							userTO.setUserName((String) myRslt.getString("user_name"));
							userTO.setRole((String) myRslt.getString("role"));
							userTO.setPassword("******");
							verifyAuthentication = true;
					}
				}
			}
			catch(SQLException e)
			{
				throw new MVCApplicationException(e);
			}
		
		
			
			return verifyAuthentication;
		
		
	}

}
