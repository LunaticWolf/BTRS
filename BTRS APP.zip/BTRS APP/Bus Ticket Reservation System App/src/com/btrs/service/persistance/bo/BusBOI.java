package com.btrs.service.persistance.bo;

import java.sql.SQLException;

import com.btrs.model.entity.BusTO;

public interface BusBOI 
{

	public boolean validateBusEntry(BusTO busTO) throws  SQLException;
	
}
