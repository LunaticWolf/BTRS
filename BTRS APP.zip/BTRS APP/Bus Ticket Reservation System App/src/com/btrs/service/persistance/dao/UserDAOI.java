package com.btrs.service.persistance.dao;

import java.sql.SQLException;

import com.btrs.model.entity.UserTO;
import com.btrs.service.exception.MVCApplicationException;

public interface UserDAOI 
{

	public boolean verifyUserAuthentication(UserTO userTO) throws MVCApplicationException, SQLException;
	
}
