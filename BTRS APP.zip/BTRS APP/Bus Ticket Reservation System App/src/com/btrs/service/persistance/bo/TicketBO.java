package com.btrs.service.persistance.bo;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.btrs.model.entity.BusTO;
import com.btrs.model.entity.RouteTO;
import com.btrs.model.entity.TicketTO;
import com.btrs.service.persistance.dao.TicketDAO;

public class TicketBO 
{
	TicketDAO ticketDAO = new TicketDAO();
	
	
	
	
	//Step 1 - Verify Customer Booking ID
	public boolean verifyBookingID(String customerID) throws SQLException
	{
		boolean validateEligiblity = false;
		int count = validate(customerID);

		if(!(count>0))
		{
			validateEligiblity = ticketDAO.verifyBookingID(customerID);
		}
		
		return validateEligiblity;
	}
	
	
	//Validate Step 1
	public int validate(String customerID)
	{
		int count = 0;
		String numberPattern = "^[0-9]{10}$";
		
		if( (customerID==null) || (customerID.isEmpty()) )
		{
			count++;
		}
		
		if(!(customerID.matches(numberPattern)))
		{
			count++;
		}
		
		return count;
	}
	
	
	
	
	
	
	//Step 2
	//Booking Journey Dates ------------------------------------------------------------------------------------------------------------
	
	
	public List<TicketTO> getBookingDetails(TicketTO ticketTO) throws SQLException, ParseException
	{
		int count = validateCities(ticketTO);
		
		List<TicketTO> scheduleDetails = new ArrayList<TicketTO>();
		List<TicketTO> jDates = new ArrayList<TicketTO>();
		
		if(!(count>0))
		{
			TicketDAO ticketDAO = new TicketDAO();
			scheduleDetails = ticketDAO.getSchedule(ticketDAO.getBookingDetails(ticketTO));
			
			for(TicketTO jDate : scheduleDetails)
			{
				jDates.add(ticketDAO.getJourneyDate(jDate));
			}
			
			
		}
		
		
		return jDates;
	}
	
	
	
	//validate Step 2
	public int validateCities(TicketTO ticketTO)
	{
		int count = 0;
		String AlphaPattern = "^[a-zA-Z]{0,5}$";
		
		
		String fromCity = ticketTO.getFromCity();
		String toCity = ticketTO.getToCity();
		
		if((fromCity == null) || (fromCity.isEmpty()) )
		{
			count++;
		}
		
		if(!(fromCity.matches(AlphaPattern)))
		{
			count++;
		}
		
		if((toCity==null) || (toCity.isEmpty()) )
		{
			count++;
		}
		
		if(!(toCity.matches(AlphaPattern)))
		{
			count++;
		}
		
		return count;	
	}



	
	
	
	
	
	
	
	
	//Step - 3 -------------------------------------------------------------------------------------------------------------------------------
	public List<String> getTransportationDetails(TicketTO ticketTO) throws ParseException, SQLException 
	{
	
		String strJourneyDate = ticketTO.getStrJourneyDate();
		
		TicketTO data = ticketTO;
		int count = validateDate(ticketTO);
		List<String> busSchedule = new ArrayList<>();
		if(!(count>0))
		{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date journeyDate = sdf.parse(strJourneyDate);
			ticketTO.setJourneyDate(journeyDate);
			
			TicketDAO ticketDAO = new TicketDAO();
			busSchedule = ticketDAO.getTransportationDetails(ticketTO);
		}
		return busSchedule;
		
	}
	



	 public int validateDate(TicketTO ticketTO)
	 {
		 String date = ticketTO.getStrJourneyDate();
		 int count = 0;
		 
		 if(date.equals("-"))
		 {
			 count++;
		 }
		 
		 return count;
				 
	 }


	 
	 
	 
	 
	 
	 
	 //Prefill Data-------------------------------------------------------------------------------------------------------------------------------
	 
	
		public List<String> getCostDetails(TicketTO ticketTO) throws SQLException 
		{
			return ticketDAO.getCostDetails(ticketTO);	
		}
	
	
	
		public List<BusTO> getBusDetails(String scheduleId) throws SQLException 
		{
			
			return ticketDAO.getBusDetails(scheduleId);
		}
	
	
	
		public List<String> getSeatsDetails(String scheduleId) throws SQLException 
		{
			return ticketDAO.getSeatsDetails(scheduleId);
		}
	
	
	
		public List<String> getScheduleTime(String scheduleId) throws SQLException
		{
			return ticketDAO.getScheduleTime(scheduleId);
		}

		
		
		
		
		
		
		
		
		
//Step 4---------------------------------------------------------------------------------------------------------------------------------------------

		public String getTickets(TicketTO ticketTO) throws ParseException, SQLException 
		{
		
			int count = validateEntries(ticketTO);
			
			String bookedTicket = null;
			if(!(count>0))
			{
				String jDate = ticketTO.getStrJourneyDate();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date date = sdf.parse(jDate);
				ticketTO.setJourneyDate(date);
				
				
				
				
				ticketTO.setNoOfTickets(Integer.parseInt(ticketTO.getStrNoOfTickets()));
				ticketTO.setCost(Double.parseDouble(ticketTO.getStrCost()));
				
				double cost = ticketTO.getNoOfTickets() * ticketTO.getCost();
				ticketTO.setCost(cost);
				
			
				
				ticketTO.setTicketID(generateTicketID(ticketTO));
				bookedTicket = ticketDAO.bookTickets(ticketTO);
			}
				
			return bookedTicket;
			
			
		}



		private int validateEntries(TicketTO ticketTO) 
		{
		
		int count = 0;
		
	
		
		String busID = ticketTO.getBus().getBusId();
		String seats = ticketTO.getStrNoOfTickets();
		String time = ticketTO.getTime();
		String cost = ticketTO.getStrCost();
		
		if((busID.equals("-")))
		{
			count++;
		}
			
		if((seats.equals("-") || Integer.parseInt(seats)>4))
		{
			count++;
		}
		
		if(time.equals("-"))
		{
			count++;
		}
		
		if(cost.equals("-"))
		{
			count++;
			
		}
			
			return count;
		}



		private String generateTicketID(TicketTO ticketTO) throws SQLException 
		{
		
			StringBuilder sb = new StringBuilder();
			sb.append(ticketTO.getBus().getBusId());
			
			 DateFormat dateFormat1 = new SimpleDateFormat("ddMMYY");
			 Date date = new Date();
			 sb.append(dateFormat1.format(date));
			 
			String ticketID = ticketDAO.generateTicketID(null);
			
			return sb.append(ticketID).toString();
		}



		public TicketTO viewTicketDetails(String ticketID) throws SQLException 
		{
			return ticketDAO.viewTicket(ticketID);	
		}
	 
	 
	 
	 
	 }
	
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------























































/*import java.sql.SQLException;
import java.util.List;

import com.btrs.model.entity.TicketTO;
import com.btrs.service.persistance.dao.TicketDAO;
import com.btrs.service.persistance.dao.TicketDAOI;

public class TicketBO implements TicketBOI
{	
	
	
	
	@Override
	public List<TicketTO> getTickets(String customerID) throws SQLException 
	{
	
		TicketDAOI ticketDAOI = (TicketDAOI) new TicketDAO();
		
		return ticketDAOI.getCustomerTickets(customerID);
	}





	@Override
	public boolean cancelReservation(String ticketID) throws SQLException 
	{
		
		TicketDAOI ticketDAOI = (TicketDAOI) new TicketDAO();
		
		return ticketDAOI.cancelReservation(ticketID);
		
	}





	@Override
	public boolean getTravelDetails(TicketTO ticketTO) {
		// TODO Auto-generated method stub
		return false;
	}



}
*/