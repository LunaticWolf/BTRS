package com.btrs.service.constants;

public class ErrorConstants 
{

	public static final String LOGIN_PAGE = "Login.jsp";
	
	public static final String CUSTOMER_REGISTRATION_PAGE = "customer-registration-page.jsp";
	public static final String UPDATE_CUSTOMER_ID = "update-customer-id.jsp";
	public static final String NO_RECORDS_AVALIABLE = "view-customer-record.jsp";
	public static final String HOME_PAGE = "home.jsp";
	
	
	
	
	
	
	
	public static final String VERIFY_BOOKER = "booker-verification.jsp";

	
	//Booking Details
		public static final String TICKETS_BOOKED_BY = "tickets-booked-by.jsp";
		public static final String TRAVEL_DETAILS = "booking-details.jsp";
		public static final String CHECK_TICKETS = "avaliable-journey-dates";
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		public static final String EMPTY_USER_PASSWORD = "Empty Username or Password";
		public static final String INVALID_USER_PASSWORD = "Invalid Username & Password";
		public static final Object LOGIN_ERROR = "Un-Authorized User LogIn";
}
