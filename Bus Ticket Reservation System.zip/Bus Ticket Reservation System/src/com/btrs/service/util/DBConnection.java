package com.btrs.service.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;


public class DBConnection  implements DBConnectionI
{
	
	static String user = null;
	static String password = null;
	static String url = null;
	static String driver = null;
	
	static Connection myConn = null;
	
	
	 
	public Connection getMySQLConnection()
	{
		ResourceBundle bundle = ResourceBundle.getBundle("mysql-db");
		
		user = bundle.getString("db.username");
		password = bundle.getString("db.password");
		url = bundle.getString("db.url");
		driver = bundle.getString("db.driver");
		
		
		try
		{
			Class.forName(driver);
			myConn = DriverManager.getConnection(url, user, password);
			System.out.println("Connection Established");
		}
		catch(ClassNotFoundException | SQLException e)
		{
			
			//HAndle Exceptions 
			e.printStackTrace();
			//throw new MVCApplicationException(e);
		}
		
		return myConn;
	
	}	
}
