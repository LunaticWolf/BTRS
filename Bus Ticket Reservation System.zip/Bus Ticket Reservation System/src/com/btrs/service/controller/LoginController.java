package com.btrs.service.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.btrs.model.entity.UserTO;
import com.btrs.service.constants.ErrorConstants;
import com.btrs.service.constants.SuccessConstants;
import com.btrs.service.exception.MVCApplicationException;

import com.btrs.service.persistance.bo.UserBO;
import com.btrs.service.persistance.bo.UserBOI;



public class LoginController extends HttpServlet
{

	private static final long serialVersionUID = 1L;
       
   
    public LoginController() 
    {
        super();    
   }

	
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		RequestDispatcher requestDispatcher = request.getRequestDispatcher(SuccessConstants.LOGIN_PAGE);
		
		requestDispatcher.forward(request, response);
		
	}

	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		String userId = request.getParameter("UserId");
		String password = request.getParameter("password");
		
		UserTO userTO = new UserTO(userId, password);
		
		RequestDispatcher requestDispatcher = request.getRequestDispatcher(SuccessConstants.HOME_PAGE);
		UserBOI userBO = new UserBO();
		try 
		{
		
			System.out.println("Into BO");
			boolean validUser = userBO.validateUser(userTO);
			
			if(validUser)
			{
				System.out.println("Coming Back");
				HttpSession session = request.getSession();
				session.setAttribute("Welcome", userTO);
			}
			else
			{
				//Handle Exception
				throw new MVCApplicationException();
			}
		
		} 
		catch (MVCApplicationException e) 
		{
			//Handle Exception - Add Error Map
			request.setAttribute("Un-Authenticated User", "Error-Message");
			requestDispatcher = request.getRequestDispatcher(ErrorConstants.LOGIN_PAGE);
			
		}
		
	
		requestDispatcher.forward(request, response);
		
		
		
	}

}
