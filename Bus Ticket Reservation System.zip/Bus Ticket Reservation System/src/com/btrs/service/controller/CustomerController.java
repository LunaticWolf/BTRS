package com.btrs.service.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.btrs.model.entity.CityTO;
import com.btrs.model.entity.CountryTO;
import com.btrs.model.entity.CustomerTO;
import com.btrs.model.entity.CustomerTypeTO;
import com.btrs.model.entity.StateTO;
import com.btrs.model.entity.ZipCodeTO;
import com.btrs.service.constants.ErrorConstants;
import com.btrs.service.constants.SuccessConstants;
import com.btrs.service.exception.MVCApplicationException;
import com.btrs.service.persistance.bo.CustomerBO;
import com.btrs.service.persistance.bo.CustomerBOI;
import com.btrs.service.persistance.bo.GPSBO;


public class CustomerController extends HttpServlet 
{
	
	
	private static final long serialVersionUID = 1L;
  
	static String page = null;
	
    public CustomerController() 
    {
        super();   
    }
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		String theCommand = request.getParameter("TheCommand");
		
		
		switch (theCommand) 
			{
				case "RegisterNewCustomer" : 	getInformation(request);	
												registerNewCustomer(request,response); 
					break;
					
				case "UpdateCustomerID" : updateExistingCustomerRecord(request,response);
					break;
					
				case "ViewCustomerID": 	viewCustomerRecord(request,response);
					break;
				
				case "ViewAllCustomer" :	page = SuccessConstants.VIEW_CUSTOMERS;
											viewCustomerRecords(request,response);
					break;
	
			}
		
		deployPageRequest(request, response, page);
		
	}

	

	private void registerNewCustomer(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		page = SuccessConstants.CUSTOMER_REGISTRATION_PAGE;
	}
	
	


	private void updateExistingCustomerRecord(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		page = SuccessConstants.SEARCH_CUSTOMER_PAGE;
	}


	
	private void viewCustomerRecord(HttpServletRequest request, HttpServletResponse response) 
	{
		page = SuccessConstants.VIEW_CUSTOMER_ID;
	}

	

	private void viewCustomerRecords(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		CustomerTO customerTO = new CustomerTO();
		CustomerBOI customerBO = new CustomerBO();
		
		List<CustomerTO> getCustomers = customerBO.getCustomerRecords(customerTO);

		if(getCustomers==null)
		{
			page = ErrorConstants.NO_RECORDS_AVALIABLE;
			//Set Attribute for no records avaliable
		}
		else
			request.setAttribute("CUSTOMERRECORDS", getCustomers);
	}

	

	
	
	//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< POST METHODS >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		
		String theCommand = request.getParameter("TheCommand").toUpperCase();
		
		
		switch (theCommand) 
		{
			case "REGISTERCUSTOMERRECORD": registerCustomerRecord(request,response);
				break;
					
				
			case "GETCUSTOMERUPDATEID":	page = SuccessConstants.UPDATE_EXISTING_CUSTOMER;
										getCustomerInformation(request,response);
									
				break;
				
			case "UPDATECUSTOMERRECORD": updateCustomerRecord(request,response);
				break;
				
				
			case "GETCUSTOMERID" : page = SuccessConstants.VIEW_CUSTOMERS;
									getCustomerInformation(request, response);	
					
		}
	
		
		
			deployPageRequest(request, response, page);
		
	}



//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< UPDATE CUSTOMER >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	
	
	private void updateCustomerRecord(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		
		
		boolean customerUpdated = false;

		String customerName = request.getParameter("CustomerName");
		String customerAddress = request.getParameter("CustomerAddress");
		String customerCountryId = request.getParameter("CustomerCountry");
		String customerStateId = request.getParameter("CustomerState");
		String customerCityId = request.getParameter("CustomerCity");
		String customerZipCode = request.getParameter("CustomerAddressCode");
		String customerEmail = request.getParameter("CustomerEmail");
		String customerId = request.getParameter("CustomerId");
		
		
		System.out.println(customerCountryId + customerCountryId.length());
		if(customerCountryId.equalsIgnoreCase("IND"))
			System.out.println("Same");
		else
			System.out.println("No");
	
		CustomerTO customerTO = new CustomerTO(customerName, customerAddress, customerCountryId, customerStateId, customerCityId, customerZipCode, customerEmail);

		CustomerBO customerBo = new CustomerBO();		
		
		RequestDispatcher requestDispatcher = request.getRequestDispatcher(SuccessConstants.HOME_PAGE);
		
		try 
		{
			customerTO.setCustomerId(customerId);
			customerUpdated = customerBo.updateCustomer(customerTO);
			
			if(customerUpdated)
			{
				//request.setAttribute("UpadationSuccessfull", SuccessConstants.CUSTOMER_SUCCESSFULLY_UPDATED);
			}
			else
			{
				//request.setAttribute("Updation Error", ErrorConstants.UPDATION_ERROR);
				requestDispatcher = request.getRequestDispatcher(ErrorConstants.UPDATE_CUSTOMER_ID);
			}
		}
		catch (MVCApplicationException | SQLException e) 
		{
			e.printStackTrace();
		}
		
		
		requestDispatcher.forward(request, response);
		
		
	}
		
		
		
		
	//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< GET ID INFORMATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

	private void getCustomerInformation(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		
		String customerId = request.getParameter("CustomerId");
		
		
		try 
		{
			CustomerBO customerBO = new CustomerBO();
			CustomerTO customerTO = customerBO.getRequestedCustomerRecord(customerId);
			if(customerTO!=null)
			{
				System.out.println("Update Avaliable");
				request.setAttribute("CUSTOMER_DETAILS", customerTO);
			}
			else
			{
				System.out.println("Update Not Avaliable");
				page = ErrorConstants.UPDATE_CUSTOMER_ID;
				//request.setAttribute("UpdateError", ErrorConstants.CUSTOMER_UPDATION_NOT_AVALIABLE);
			}
			
		}
		catch (MVCApplicationException | SQLException e)
		{	
			e.printStackTrace();
		}
		
		
	}


	
	
	
	
	
	
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< ADD a NEW CUSTOMER >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

	
	private void registerCustomerRecord(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		
		boolean registered = false;
		
		String customerName = request.getParameter("CustomerName");
		String customerAddress = request.getParameter("CustomerAddress");
		String customerCountryId = request.getParameter("CustomerCountry");
		String customerStateId = request.getParameter("CustomerState");
		String customerCityId = request.getParameter("CustomerCity");
		String customerZipCode = request.getParameter("CustomerAddressCode");
		String customerEmail = request.getParameter("CustomerEmail");
		String customerGender = request.getParameter("CustomerGender");
		String strCustomerContactNumber = request.getParameter("CustomerContactNumber");
		String strCustomerDOB = request.getParameter("CustomerDOB");
		String customerType = request.getParameter("CustomerType");
		String customerPassword = request.getParameter("CustomerPassword");
		
		CustomerTO customerTO = new CustomerTO(customerName, customerAddress, customerCountryId, customerStateId, customerCityId, customerZipCode, customerEmail, customerGender, strCustomerContactNumber, strCustomerDOB, customerType, customerPassword);
		CustomerBOI customerBO = new CustomerBO();
		
		try 
		{
			registered = customerBO.validateCustomerId(customerTO);
			if(registered)
				{
					page = SuccessConstants.HOME_PAGE;
					//Goes to hompage with a success attribute(Customer ID);		
				}
			else
				{
					page = ErrorConstants.CUSTOMER_REGISTRATION_PAGE;
					//goes back to registration page with respective error.
					//handle exception and  add map error from BO and DAO
				}
		}
		 catch (SQLException| MVCApplicationException | ParseException e) 
		{
			 //Handle exceptions
			e.printStackTrace();
		} 
		
	}
	
	
	
	
	
	
	
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< GET PREFILLS >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>	
	
	
	
	private void getInformation(HttpServletRequest request)  
	{
		
		
		CountryTO countryTO = new CountryTO();
		StateTO stateTO = new StateTO();
		CityTO cityTO = new CityTO();
		ZipCodeTO zipCodeTO = new ZipCodeTO();	
		CustomerTypeTO customerTypeTO = new CustomerTypeTO();
		
		
		GPSBO gpsBO = new GPSBO();
		CustomerBO customerBO = new CustomerBO();
		try 
		{
			
			request.setAttribute("COUNTRIES", gpsBO.getCountries(countryTO));
			request.setAttribute("STATES", gpsBO.getStates(stateTO));
			request.setAttribute("CITIES", gpsBO.getCities(cityTO));
			request.setAttribute("ZIPCODES", gpsBO.getZipCodes(zipCodeTO));
			request.setAttribute("CUSTOMERTYPE", customerBO.getCustomerType(customerTypeTO));
			
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
	}

	
	
	public void deployPageRequest(HttpServletRequest request, HttpServletResponse response,String page) throws ServletException, IOException
	{
		RequestDispatcher requestDispatcher = request.getRequestDispatcher(page);
		requestDispatcher.forward(request, response);
	}
	
	
	
	
	

}
