package com.btrs.service.persistance.bo;

import com.btrs.model.entity.UserTO;

public interface UserBOI 
{

	public boolean validateUser(UserTO userTO);
	
}
