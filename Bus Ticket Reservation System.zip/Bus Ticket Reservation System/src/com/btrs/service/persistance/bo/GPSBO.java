package com.btrs.service.persistance.bo;

import java.sql.SQLException;
import java.util.List;

import com.btrs.model.entity.CityTO;
import com.btrs.model.entity.CountryTO;
import com.btrs.model.entity.StateTO;
import com.btrs.model.entity.ZipCodeTO;
import com.btrs.service.persistance.dao.GPSDAO;


public class GPSBO
{
	
	GPSDAO gpsDAO = new GPSDAO();
	
	public List<CountryTO> getCountries(CountryTO countryTO) throws SQLException
	{
		return gpsDAO.getCountries(countryTO);
	}

	
	public List<StateTO> getStates(StateTO stateTO) throws  SQLException 
	{
		return gpsDAO.getStates(stateTO);
	}
	
	
	public List<CityTO> getCities(CityTO cityTO) throws  SQLException
	{
		return gpsDAO.getCities(cityTO);
	}
	
	public List<ZipCodeTO> getZipCodes(ZipCodeTO zipCodeTO) throws  SQLException
	{
		return gpsDAO.getZipCodes(zipCodeTO);
	}
	
}
