package com.btrs.service.persistance.dao;

import com.btrs.model.entity.UserTO;

public interface UserDAOI 
{

	public boolean verifyUserAuthentication(UserTO userTO);
	
}
