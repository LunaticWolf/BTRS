package com.btrs.service.persistance.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.btrs.model.entity.BusTypeTO;
import com.btrs.service.util.DBConnection;
import com.btrs.service.util.DBConnectionI;

public class BusTypeDAO 
{

	static Connection myConn = null;
	static Statement stmt = null;
	static ResultSet myResultSet = null;
	
	
	public List<BusTypeTO> getBusTypes(BusTypeTO busTypeTO) throws SQLException
	{
		
		String Query = "Select * from Bus type table";
		
		DBConnectionI  db = new DBConnection();
		myConn = db.getMySQLConnection();
		
		stmt = myConn.createStatement();
		myResultSet = stmt.executeQuery(Query);
		
		
		List<BusTypeTO> busTypeList = new ArrayList<BusTypeTO>();
		if(myResultSet.next())
		{
			String busType = myResultSet.getString("bus_type");
			String seatsAvaliable = myResultSet.getString("seats_avaliable");
			
			busTypeTO = new BusTypeTO(busType, seatsAvaliable);
			busTypeList.add(busTypeTO);
		}
		
		
		return busTypeList;
		
		
	}
	
}
