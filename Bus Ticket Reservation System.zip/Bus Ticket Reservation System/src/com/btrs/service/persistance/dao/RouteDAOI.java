package com.btrs.service.persistance.dao;

import java.sql.SQLException;

import com.btrs.model.entity.RouteTO;

public interface RouteDAOI 
{

	public String generateRouteId(String id) throws SQLException;
	public boolean addNewRoute(RouteTO routeTO) throws SQLException; 
	
}
