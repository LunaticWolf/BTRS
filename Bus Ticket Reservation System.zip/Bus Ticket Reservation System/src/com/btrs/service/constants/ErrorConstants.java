package com.btrs.service.constants;

public class ErrorConstants 
{

	public static final String LOGIN_PAGE = "Login.jsp";
	public static final String CUSTOMER_REGISTRATION_PAGE = "customer-registration-page.jsp";
	public static final String UPDATE_CUSTOMER_ID = "update-customer-id.jsp";
	public static final String NO_RECORDS_AVALIABLE = "view-customer-records";

}
