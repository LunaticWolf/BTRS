package com.btrs.service.constants;

public class SuccessConstants 
{

	public static final String LOGIN_PAGE = "Login.jsp";
	public static final String HOME_PAGE = "Home.jsp";
	
	
	public static final String CUSTOMER_REGISTRATION_PAGE = "customer-registration-page.jsp";
	
	public static final String SEARCH_CUSTOMER_PAGE = "update-customer-id.jsp";
	public static final String UPDATE_EXISTING_CUSTOMER = "update-existing-customer.jsp";
	
	public static final String VIEW_CUSTOMER_ID = "view-customer-id.jsp";
	public static final String VIEW_CUSTOMERS = "view-customer-record.jsp";
	public static final String ADD_NEW_BUS = "add-bus.jsp";
	public static final String ADD_NEW_ROUTE = "add-route.jsp";
	public static final String ADD_NEW_SCHEDULE = "add-schedule.jsp";


}
