package com.btrs.service.persistance.bo;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import com.btrs.model.entity.CustomerTO;
import com.btrs.model.entity.CustomerTypeTO;
import com.btrs.service.exception.MVCApplicationException;

public interface CustomerBOI 
{

	//Prefill Record
	public List<CustomerTypeTO> getCustomerType(CustomerTypeTO customerTypeTO) throws SQLException;
	
	//Add Entry
	public void generateCustomerId(CustomerTO customerTO) throws SQLException, MVCApplicationException;


	//VAlidate Entries
	public boolean validateCustomerId(CustomerTO customerTO) throws ParseException, SQLException, MVCApplicationException;
	
	
	//Get Update ID/Specific Record
	public CustomerTO getRequestedCustomerRecord(String customerId) throws MVCApplicationException, SQLException;
	
	//Update - U
	public boolean updateCustomer(CustomerTO customerTO) throws MVCApplicationException, SQLException;
	
	
	//View All Records - R
	public List<CustomerTO> getCustomerRecords(CustomerTO customerTO);
}
