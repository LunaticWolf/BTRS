package com.btrs.service.persistance.bo;

import com.btrs.model.entity.UserTO;
import com.btrs.service.exception.MVCBusinessException;
import com.btrs.service.persistance.dao.UserDAO;
import com.btrs.service.persistance.dao.UserDAOI;


public class UserBO implements UserBOI
{

	@Override
	public boolean validateUser(UserTO userTO) 
	{
		
		boolean validateUser = false;
		
		String user = userTO.getUserId();
		String password = userTO.getPassword();
		
		String userIdPattern = "^[0-9]*$";
		String passwordPattern = "^[a-zA-Z0-9_]*$";
		
		
		
		if(!(user.isEmpty()) && (!(user==null)) && (user.length()<11) && ((user.matches(userIdPattern)) && (!(password.isEmpty())) && (!(password==null)) && (password.matches(passwordPattern))))
		{
			
			UserDAOI userDAO = new UserDAO();
			System.out.println("Into Dao");
			validateUser = userDAO.verifyUserAuthentication(userTO);
			
		}
		/*else
			throw new MVCBusinessException();
		*/
		
		System.out.println("Back to Controller");
		return validateUser;
		
	}

}
