package com.btrs.service.persistance.bo;

import java.sql.SQLException;

import com.btrs.model.entity.RouteTO;

public interface RouteBOI 
{

	public boolean validateRouteEntry(RouteTO routeTO) throws  SQLException;
	
	
}
