package com.btrs.service.persistance.bo;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.btrs.model.entity.TicketTO;
import com.btrs.service.persistance.dao.TicketDAO;

public class TicketBO 
{

	
	public boolean verifyBookingID(String customerID) throws SQLException
	{
		boolean validateAuthorization = false;
		int count = validate(customerID);

		if(!(count>0))
		{
			TicketDAO ticketDAO = new TicketDAO();
			validateAuthorization = ticketDAO.verifyBookingID(customerID);
		}
		
		return validateAuthorization;
	}
	
	
	
	public int validate(String customerID)
	{
		int count = 0;
		String numberPattern = "^[0-9]{10}$";
		
		if( (customerID==null) || (customerID.isEmpty()) )
		{
			count++;
		}
		
		if(!(customerID.matches(numberPattern)))
		{
			count++;
		}
		
		
		return count;
	}
	
	
	
	
	
	//Booking Details ------------------------------------------------------------------------------------------------------------
	
	
	public List<TicketTO> getBookingDetails(TicketTO ticketTO) throws SQLException
	{
		int count = detailsAvaliable(ticketTO);
		List<TicketTO> scheduleDetails = new ArrayList<TicketTO>();
		List<TicketTO> jDates = new ArrayList<TicketTO>();
		
		if(!(count>0))
		{
			TicketDAO ticketDAO = new TicketDAO();
			scheduleDetails = ticketDAO.getSchedule(ticketDAO.getBookingDetails(ticketTO));
			
			for(TicketTO jDate : scheduleDetails)
			{
				jDates.add(ticketDAO.getJourneyDate(jDate));
			}
			
			
		}
		
		
		return jDates;
	}
	
	
	public int detailsAvaliable(TicketTO ticketTO)
	{
		int count = 0;
		String AlphaPattern = "^[a-zA-Z]{0,5}$";
		
		
		String fromCity = ticketTO.getFromCity();
		String toCity = ticketTO.getToCity();
		
		if((fromCity == null) || (fromCity.isEmpty()) )
		{
			count++;
		}
		
		if(!(fromCity.matches(AlphaPattern)))
		{
			count++;
		}
		
		if((toCity==null) || (toCity.isEmpty()) )
		{
			count++;
		}
		
		if(!(toCity.matches(AlphaPattern)))
		{
			count++;
		}
		
		return count;	
	}



	public List<TicketTO> getTransportationDetails(TicketTO ticketTO) 
	{
		return null;
	}
	
}
