package com.btrs.service.persistance.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.btrs.model.entity.RouteTO;
import com.btrs.service.exception.MVCApplicationException;
import com.btrs.service.util.DBConnection;
import com.btrs.service.util.DBConnectionI;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

public class RouteDAO 
{
	
	static Connection myConn=null;
	static PreparedStatement pStmt = null;	
	static ResultSet myRslt = null;
	static Statement stmt = null;
	
	//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< ADD ROUTE >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

		public String generateRouteId(String id) throws SQLException
		{
			
			String query = " select lpad(cast(ifnull(max(cast(substr(route_id,2) as decimal )),0)+1 as character),1,'0') as route_id from route_details";
			
			DBConnectionI db = new DBConnection();
			myConn = db.getMySQLConnection();
			
			stmt = (Statement) myConn.createStatement();
			myRslt = stmt.executeQuery(query);
			
			if(myRslt.next())
			{
				id = myRslt.getString("route_id");
			}
			
			return id;
			
		}


		public boolean addNewRoute(RouteTO routeTO) throws SQLException 
		{
			
			boolean registered = false;
			
			DBConnection db = new DBConnection();
			myConn = db.getMySQLConnection();
			String query = "insert into route_details(route_id, route_from, route_to, travel_cost) value(?,?,?,?)";
			
			pStmt = (PreparedStatement) myConn.prepareStatement(query);
			
			pStmt.setString(1, routeTO.getRouteId());
			pStmt.setString(2, routeTO.getRouteFrom());
			pStmt.setString(3, routeTO.getRouteTo());
			pStmt.setString(4, routeTO.getTravelCost());
			
			
			int n = pStmt.executeUpdate();
			
			if(n==1)
				registered = true;
				
				
			return registered;
		}
	
}
