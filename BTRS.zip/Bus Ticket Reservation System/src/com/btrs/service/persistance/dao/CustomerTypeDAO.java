package com.btrs.service.persistance.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.btrs.model.entity.CustomerTypeTO;
import com.btrs.service.util.DBConnection;
import com.btrs.service.util.DBConnectionI;

public class CustomerTypeDAO implements CustomerTypeDAOI
{	
	
	static Connection myConn = null;
	static Statement stmt = null;
	static ResultSet myRslt = null;
	
	public List<CustomerTypeTO> getCustomerType(CustomerTypeTO customerTypeTO) throws  SQLException
	{
	
		
		DBConnectionI db = new DBConnection();
		myConn = db.getMySQLConnection();
		
		stmt = myConn.createStatement();
		myRslt = stmt.executeQuery("select * from customer_type_identifier");
		
		List<CustomerTypeTO> customerTypeList = new ArrayList<CustomerTypeTO>();
		if(myRslt.next())
		{
			customerTypeTO.setCustomerTypeId((String)myRslt.getString("customer_type_id"));
			customerTypeTO.setCustomerType((String)myRslt.getString("customer_type"));
			
			
			customerTypeList.add(customerTypeTO);
		}
		
		
		return customerTypeList;
		
	}
	
}
