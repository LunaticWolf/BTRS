package com.btrs.service.persistance.dao;

import java.sql.SQLException;
import java.util.List;

import com.btrs.model.entity.CustomerTO;

public interface CustomerDAOI 
{

	public String getId(String id) throws SQLException;
	public boolean addCustomer(CustomerTO customerTO) throws SQLException;
	

	public CustomerTO getCustomerUpdate(String customerId) throws  SQLException;
	public boolean updateCustomer(CustomerTO customerTO) throws  SQLException;
	
	public List<CustomerTO> getCustomerRecords(CustomerTO customerTO);

}
