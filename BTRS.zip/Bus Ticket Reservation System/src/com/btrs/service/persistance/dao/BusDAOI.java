package com.btrs.service.persistance.dao;

import java.sql.SQLException;
import java.util.List;

import com.btrs.model.entity.BusTO;

public interface BusDAOI 
{

	public String generateBusId(String id) throws SQLException;
	public boolean addNewBus(BusTO busTO) throws SQLException;
	public List<BusTO> getBusses(BusTO busTO) throws SQLException;
	
}
