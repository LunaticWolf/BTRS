package com.btrs.service.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.btrs.model.entity.BusScheduleTO;
import com.btrs.model.entity.RouteTO;
import com.btrs.model.entity.TicketTO;
import com.btrs.service.constants.QueryConstants;
import com.btrs.service.util.DBConnection;

import sun.net.www.content.text.plain;

public class TicketDAO 
{

	static Connection myConn = null;
	static PreparedStatement pStmt = null;
	static ResultSet myRslt = null;
	
	
	public boolean verifyBookingID(String customerID) throws SQLException
	{
		
		boolean verifyAuthentication = false;
		
		DBConnection db = new DBConnection();
		myConn = db.getMySQLConnection();
		
		pStmt = myConn.prepareStatement(QueryConstants.TICKETS_BOOKED_BY);
		pStmt.setString(1, customerID);
		
		myRslt = pStmt.executeQuery();
		
		if(myRslt.next())
		{
			verifyAuthentication = true;
		}
		
		return verifyAuthentication;
		
	}
	
	
//////--------------------------------------------------- Get Details ---------------------------------------------------------	
	
	
	
	public TicketTO getBookingDetails(TicketTO ticketTO) throws SQLException
	{
		
		DBConnection db = new DBConnection();
		myConn = db.getMySQLConnection();
		
		pStmt = myConn.prepareStatement(QueryConstants.GET_LOCATION_DETAILS);
		pStmt.setString(1, ticketTO.getFromCity());
		pStmt.setString(2, ticketTO.getToCity());
		
		myRslt = pStmt.executeQuery();
		TicketTO travelInfo = new TicketTO();
		while(myRslt.next())
		{
			
			
			String routeId = myRslt.getString("route_id");
			
			RouteTO routeTO = new RouteTO();
			routeTO.setRouteId(routeId);
			travelInfo.setRouteTO(routeTO);
			
		}
		
		
		
		return travelInfo;
	}


	public List<TicketTO> getSchedule(TicketTO routeInfo) throws SQLException 
	{	
		
		String routeID = routeInfo.getRouteTO().getRouteId();
		
		List<TicketTO> schedule = new ArrayList<TicketTO>();
		
		if(routeID!=null)
		{
			DBConnection db = new DBConnection();
			myConn = db.getMySQLConnection();
			
			pStmt = myConn.prepareStatement(QueryConstants.GET_SCHEDULE);
			pStmt.setString(1, routeID);
			
			myRslt = pStmt.executeQuery();
		
			while(myRslt.next())
			{
				TicketTO ticketTO = new TicketTO();
				String scheduleID = myRslt.getString("schedule_id");
				
				BusScheduleTO busScheduleTO = new BusScheduleTO();
				busScheduleTO.setScheduleId(scheduleID);
				ticketTO.setBusScheduleTO(busScheduleTO);
				
				schedule.add(ticketTO);
			}
		}
		
		
		
		
		return schedule;
	}


	public TicketTO getJourneyDate(TicketTO jDate) throws SQLException 
	{
		
		DBConnection db = new DBConnection();
		myConn = db.getMySQLConnection();
		
		pStmt = myConn.prepareStatement("select journey_date from schedule_information where scheduleId = ?");
		pStmt.setString(1, jDate.getBusScheduleTO().getScheduleId());
		
		TicketTO dates = new TicketTO();
		while(myRslt.next())
		{
			java.util.Date date = myRslt.getTimestamp("journey_date");
			dates.setJourneyDate(date);
		}
		
		
		return dates;
	}
	
	
	
}
