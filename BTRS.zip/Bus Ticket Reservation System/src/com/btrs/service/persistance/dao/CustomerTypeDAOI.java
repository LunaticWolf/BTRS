package com.btrs.service.persistance.dao;

import java.sql.SQLException;
import java.util.List;

import com.btrs.model.entity.CustomerTypeTO;

public interface CustomerTypeDAOI 
{

	public List<CustomerTypeTO> getCustomerType(CustomerTypeTO customerTypeTO) throws  SQLException;
	
	
}
