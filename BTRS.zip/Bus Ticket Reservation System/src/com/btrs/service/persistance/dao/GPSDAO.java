package com.btrs.service.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.btrs.model.entity.CityTO;
import com.btrs.model.entity.CountryTO;
import com.btrs.model.entity.StateTO;
import com.btrs.model.entity.ZipCodeTO;
import com.btrs.service.util.DBConnection;
import com.btrs.service.util.DBConnectionI;


public class GPSDAO implements GPSDAOI 
{

	static Connection myConn = null;
	static Statement stmt = null;
	static PreparedStatement pStmt = null;
	static ResultSet myRslt = null;
	
	
	public List<CountryTO> getCountries(CountryTO countryTO) throws SQLException
	{
		
		DBConnectionI db = new DBConnection();
		myConn = db.getMySQLConnection();
		
		stmt = myConn.createStatement();
		myRslt = stmt.executeQuery("Select * from country");
		
		List<CountryTO> countryList = new ArrayList<CountryTO>();
		while(myRslt.next())
		{
			countryTO.setCountryId((String)myRslt.getString("country_id"));
			countryTO.setCountryName((String)myRslt.getString("country_name"));
			
			countryList.add(countryTO);
			
		}
		
		
		//System.out.println("Countries - " + countryList.size());
		return countryList;
		
	}
	
	
	
	public List<StateTO> getStates(StateTO stateTO) throws  SQLException
	{
		
		DBConnection db = new DBConnection();
		myConn = db.getMySQLConnection();
		
		stmt = myConn.createStatement();
		myRslt = stmt.executeQuery("Select * from states");
		
		/*pStmt = myConn.prepareStatement("Select * from states where country_id = '?'");
		pStmt.setString(1, stateTO.getCountry().getCountryId());
		myRslt = pStmt.executeQuery();*/
		
		
		List<StateTO> statesList = new ArrayList<>();
		
		while(myRslt.next())
		{
			
			stateTO.setStateId((String)myRslt.getString("state_id"));
			stateTO.setStateName((String)myRslt.getString("state_name"));
			
			statesList.add(stateTO);
		}
		
		return statesList;
		
	}
	
	
	
	public List<CityTO> getCities(CityTO cityTO) throws  SQLException
	{
		
		DBConnection db = new DBConnection();
		myConn = db.getMySQLConnection();
		
		stmt = myConn.createStatement();
		myRslt = stmt.executeQuery("Select * from cities");
		
/*		pStmt = myConn.prepareStatement("Select * from cities where country_id = '?' and state_id = '?'");
		pStmt.setString(1, cityTO.getCountry().getCountryId());
		pStmt.setString(2, cityTO.getState().getStateId());
		myRslt = pStmt.executeQuery();*/
		
		
		List<CityTO> cityList = new ArrayList<>();
		
		while(myRslt.next())
		{
			
			cityTO.setCityId((String)myRslt.getString("city_id"));
			cityTO.setCityName((String)myRslt.getString("city_name"));
			
			cityList.add(cityTO);
		}
		
		return cityList;
		
	}
	
	
	
	
	public List<ZipCodeTO> getZipCodes(ZipCodeTO zipCodeTO) throws  SQLException
	{
		
		DBConnection db = new DBConnection();
		myConn = db.getMySQLConnection();
		
		stmt = myConn.createStatement();
		myRslt = stmt.executeQuery("Select * from city_pincode");
		
		/*pStmt = myConn.prepareStatement("Select * from city_pincode where city_id = '?'");
		pStmt.setString(1, zipCodeTO.getCity().getCityId());
		myRslt = pStmt.executeQuery();*/
		
		
		List<ZipCodeTO> zipCodeList = new ArrayList<>();
		
		while(myRslt.next())
		{
			
			zipCodeTO.setZipCodeId((String) myRslt.getString("location_id"));
			zipCodeTO.setZipCode((String) myRslt.getString("zip_code"));
			
			zipCodeList.add(zipCodeTO);
		}
		
		return zipCodeList;
		
	}
	
	
	
}
