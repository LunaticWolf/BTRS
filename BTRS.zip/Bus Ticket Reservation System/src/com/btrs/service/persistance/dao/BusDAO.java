package com.btrs.service.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.btrs.model.entity.BusTO;
import com.btrs.service.util.DBConnection;
import com.btrs.service.util.DBConnectionI;


public class BusDAO  implements BusDAOI
{

	static Connection myConn=null;
	static PreparedStatement pStmt = null;	
	static ResultSet myRslt = null;
	static Statement stmt = null;
	
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  Bus Registration >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	
	
	//Generate BusId
	public String generateBusId(String id) throws SQLException
	{
		
		String query = " select lpad(cast(ifnull(max(cast(substr(bus_id,2) as decimal )),100)+1 as character),3,'0') as bus_id from bus_details";
		
		DBConnectionI db =  new com.btrs.service.util.DBConnection();
		myConn = db.getMySQLConnection();
		
		stmt = (Statement) myConn.createStatement();
		myRslt = stmt.executeQuery(query);
		
		while(myRslt.next())
		{
			id = myRslt.getString("bus_id");
		}
		
		return id;
		
		
	}
	
	
	public boolean addNewBus(BusTO busTO) throws SQLException
	{
		boolean registered = false;
		
		DBConnectionI db = new DBConnection();
		myConn = db.getMySQLConnection();
		String query = "insert into bus_details(bus_id, bus_name, bus_type, bus_capacity) value(?,?,?,?)";
		
		pStmt = (PreparedStatement) myConn.prepareStatement(query);
		
		pStmt.setString(1, busTO.getBusId());
		pStmt.setString(2, busTO.getBusName());
		pStmt.setString(3, busTO.getBusType());
		pStmt.setString(4, busTO.getAvaliableSeats());
		
		
		int n = pStmt.executeUpdate();
		
		if(n==1)
			registered = true;
			
			
		return registered;
	}


	@Override
	public List<BusTO> getBusses(BusTO busTO) throws SQLException 
	{
		
		DBConnectionI db = new DBConnection();
		myConn = db.getMySQLConnection();
	
		String query = "select * from bus_details";
		stmt = myConn.createStatement();
		myRslt = stmt.executeQuery(query);
		
		
		List<BusTO> busList = new ArrayList<BusTO>();
		while(myRslt.next())
		{
			String busId = myRslt.getString("");
			String busName = myRslt.getString("");
			
			busTO.setBusId(busId);
			busTO.setBusName(busName);
		
			busList.add(busTO);
		}
		
		return busList;
		
		
	}

	
	
	
	
	
}




