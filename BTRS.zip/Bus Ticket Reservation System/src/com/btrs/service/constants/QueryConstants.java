package com.btrs.service.constants;

public class QueryConstants {

	public static final String VERIFY_LOGIN = "Select user_name,pass_word,role from login_data where user_id = ?";
	
	
	//Module 1 Queries
	public static final String GET_CUSTOMER_ID = "Select max(customer_id) from customer";
	public static final String REGISTER_NEW_CUSTOMER = "insert into customer(customer_id,customer_name,customer_address,customer_country_id,customer_state_id, customer_city_id,customer_loc_zip_code,customer_email,customer_gender,customer_contact_no,customer_dob,customer_type,customer_reg_password) value(?,?,?,?,?,?,?,?,?,?,?,?,?)";





	
	//Module 4 Queries
	public static final String UPDATE_CUSTOMER_ID = "Select * from customer where customer_id = ?";
	public static final String UPDATE_CUSTOMER = "Update Customer set customer_name=? , customer_address=? , customer_country_id=? , customer_state_id = ? , customer_city_id = ? , customer_loc_zip_code=? , customer_email = ? where customer_id=?";


	public static final String VIEW_CUSTOMER_RECORDS = "Select * from customer";


	public static final String TICKETS_BOOKED_BY = "Select * from customer where customer_id = ?";


	public static final String GET_LOCATION_DETAILS = "Select route_id from route_details where from = ? and to = ?";


	public static final String GET_JOURNEY_DATES = "Select journey_dates from ";


	public static final String GET_SCHEDULE = "Select schedule_id from schedule_information where route_id = ?";
	
	
	

}