package com.btrs.service.util;

import java.sql.Connection;

public interface DBConnectionI 
{
	public Connection getMySQLConnection();
}
