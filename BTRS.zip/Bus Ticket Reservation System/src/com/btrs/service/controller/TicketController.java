package com.btrs.service.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.btrs.model.entity.TicketTO;
import com.btrs.service.constants.ErrorConstants;
import com.btrs.service.constants.SuccessConstants;
import com.btrs.service.persistance.bo.TicketBO;





public class TicketController extends HttpServlet 
{


	
	private static final long serialVersionUID = 1L;
          
	String page = null;
	
    public TicketController() 
    {
        super();   
    }

	
    
    
    
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< GET METHODS >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{

		String theCommand = request.getParameter("TheCommand");
	
		
		switch (theCommand) 
		{
			case "BOOKTICKET": 
								bookedBy(request,response);
				break;
		}
		

		deployPageRequest(request, response, page);
		
	}

	

	private void bookedBy(HttpServletRequest request, HttpServletResponse response) 
	{
		page = SuccessConstants.TICKETS_BOOKED_BY;
	}
	
	
	
	
	

	
	//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< POST METHODS >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>



	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		String theCommand = request.getParameter("TheCommand");
		
		
		switch (theCommand) 
		{
			case "VERIFYBOOKER" : 
									try 
									{
										verifyBooker(request,response);
									} 
									catch (SQLException e) 
									{
										e.printStackTrace();
									}
				break;
				
				
				
			case "BOOKINGDETAILS" : 
									try 
									{
										getBookingDetails(request,response);
									} 
									catch (SQLException e) 
									{
										e.printStackTrace();
									}
				break;
				
				
			case "TRANSPORTATIONDETAILS":	getTransportDetails(request,response);
				break;
		}
		
		
		
		deployPageRequest(request, response, page);
		
		
		
	}

	
	
	
	
	private void getTransportDetails(HttpServletRequest request, HttpServletResponse response) 
	{
	
		String customerID = request.getParameter("CustomerID");
		String fromCity = request.getParameter("FromCity");
		String toCity = request.getParameter("ToCity");
		String strJourneyDate = request.getParameter("JourneyDate");
		
		TicketTO ticketTO = new TicketTO(fromCity, toCity);
		ticketTO.setStrJourneyDate(strJourneyDate);
		
		TicketBO ticketBO = new TicketBO();
		List<TicketTO> journeyDetails = ticketBO.getTransportationDetails(ticketTO);
		
		
		
	}





	private void getBookingDetails(HttpServletRequest request, HttpServletResponse response) throws SQLException 
	{
	
		String fromCity = request.getParameter("fromCity");
		String toCity = request.getParameter("toCity");
		String customerID = request.getParameter("CustomerID");
		
		TicketTO ticketTO = new TicketTO(fromCity, toCity);
		request.setAttribute("CUSTOMER_DETAILS", customerID);
		request.setAttribute("CITYDETAILS", ticketTO);
		
		TicketBO ticketBO = new TicketBO();
		List<TicketTO> travelDetails = ticketBO.getBookingDetails(ticketTO);
		if(travelDetails!=null)
		{
			page = SuccessConstants.AVALIABLE_JOURNEY_DATES;
			request.setAttribute("AVALIABLEJOURNEYDATES", travelDetails);
			
		}
		else
		{
			page = ErrorConstants.TRAVEL_DETAILS;
		}
		
		
		
		
	}





	private void verifyBooker(HttpServletRequest request, HttpServletResponse response) throws SQLException 
	{
	
		String customerID = request.getParameter("CustomerID");
		
		TicketBO ticketBO = new TicketBO();
		boolean verifyAuthentication = ticketBO.verifyBookingID(customerID);
		
		if(verifyAuthentication)
		{
			request.setAttribute("BOOKINGID", customerID);
			page = SuccessConstants.BOOKING_DETAILS;
		}
		else
		{
			page = ErrorConstants.TICKETS_BOOKED_BY;
		}
		
	}

	
	
	//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DISPATCHER >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	




	public void deployPageRequest(HttpServletRequest request, HttpServletResponse response,String page) throws ServletException, IOException
	{
		RequestDispatcher requestDispatcher = request.getRequestDispatcher(page);
		requestDispatcher.forward(request, response);
	}
	
	
	
	
}
