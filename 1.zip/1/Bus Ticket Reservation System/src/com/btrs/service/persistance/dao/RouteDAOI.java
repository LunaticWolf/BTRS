package com.btrs.service.persistance.dao;

import java.sql.SQLException;

import com.btrs.model.entity.RouteTO;
import com.btrs.service.exception.MVCApplicationException;

public interface RouteDAOI 
{

	public String generateRouteId(String id) throws SQLException, MVCApplicationException;
	public boolean addNewRoute(RouteTO routeTO) throws SQLException, MVCApplicationException; 
	
}
