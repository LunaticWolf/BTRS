package com.btrs.service.persistance.dao;




import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.btrs.model.entity.BusScheduleTO;
import com.btrs.model.entity.BusTO;
import com.btrs.model.entity.CustomerTO;
import com.btrs.model.entity.RouteTO;
import com.btrs.model.entity.TicketTO;
import com.btrs.service.constants.QueryConstants;
import com.btrs.service.exception.MVCApplicationException;
import com.btrs.service.util.DBConnection;
import com.btrs.service.util.DBConnectionI;



public class TicketDAO 
{

	static Connection myConn = null;
	static PreparedStatement pStmt = null;
	static ResultSet myRslt = null;
	static Statement stmt = null;
	
	
	
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  VERIFY BOOKING ID  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>	
	
	
	
	
	public boolean verifyBookingID(String customerID) throws MVCApplicationException
	{
		
		boolean verifyEligiblity = false;
		
		try
		{
			DBConnectionI db = new DBConnection();
			myConn = db.getMySQLConnection();
			
			pStmt = myConn.prepareStatement(QueryConstants.TICKETS_BOOKED_BY);
			pStmt.setString(1, customerID);
			
			myRslt = pStmt.executeQuery();
			
			if(myRslt.next())
			{
				verifyEligiblity = true;
			}
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException(e);
		}
			
		return verifyEligiblity;
		
	}
	
	
	
	
	
//////----------------------------------------------------------- Get Details ---------------------------------------------------------	
	
	
	//Step 2 - Get Route ID
	public TicketTO getBookingDetails(TicketTO ticketTO) throws SQLException, MVCApplicationException
	{
		
		DBConnectionI db = new DBConnection();
		TicketTO travelInfo = new TicketTO();
		try
		{
			myConn = db.getMySQLConnection();
			
			pStmt = myConn.prepareStatement(QueryConstants.GET_LOCATION_DETAILS);
			pStmt.setString(1, ticketTO.getFromCity());
			pStmt.setString(2, ticketTO.getToCity());
			
			myRslt = pStmt.executeQuery();
			
			while(myRslt.next())
			{
				String routeId = (String) myRslt.getString("route_id");
				
				RouteTO routeTO = new RouteTO();
				routeTO.setRouteId(routeId);
				travelInfo.setRouteTO(routeTO);
				
				
			}
			
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException(e);
		}
		
		
		return travelInfo;
	}

	
	
	

	//Step 2 - Get Journey Dates-----------------------------------------------------------------------------------------------------------------	
		public TicketTO getJourneyDate(TicketTO jDate) throws  MVCApplicationException 
		{
			
			DBConnectionI db = new DBConnection();
			TicketTO dates = new TicketTO();
			try
			{
				myConn = db.getMySQLConnection();
				
				pStmt = myConn.prepareStatement(QueryConstants.GET_AVALIABLE_JOURNEY_DATES);
				pStmt.setString(1, jDate.getBusScheduleTO().getScheduleId());
				
				myRslt = pStmt.executeQuery();
				
				while(myRslt.next())
				{		
					dates.setStrJourneyDate((String) myRslt.getDate("date_of_journey").toString());		
				}
			}
			catch(SQLException e)
			{
				throw new MVCApplicationException(e);
			}
				
			return dates;
		}

	
		
		
		
	//Step 3 - Get Schedule Info-----------------------------------------------------------------------------------------------------------------	
	public List<TicketTO> getSchedule(TicketTO routeInfo) throws  MVCApplicationException 
	{	
		
		String routeID = routeInfo.getRouteTO().getRouteId();
		
		List<TicketTO> schedule = new ArrayList<TicketTO>();
		
		if(routeID!=null)
		{
			DBConnectionI db = new DBConnection();
			
			try
			{
				myConn = db.getMySQLConnection();
				
				pStmt = myConn.prepareStatement(QueryConstants.GET_SCHEDULE);
				pStmt.setString(1, routeID);
				
				myRslt = pStmt.executeQuery();
			
				while(myRslt.next())
				{
					TicketTO ticketTO = new TicketTO();
					String scheduleID = (String) myRslt.getString("s_id");
					
					BusScheduleTO busScheduleTO = new BusScheduleTO();
					busScheduleTO.setScheduleId(scheduleID);
					ticketTO.setBusScheduleTO(busScheduleTO);
					
					schedule.add(ticketTO);
				}
			}
			catch(SQLException e)
			{
				throw new MVCApplicationException(e);
			}
		}
		
		
		
		
		return schedule;
	}


	
	
	
	//Booking Ticket
	
	//Step 3 - Get Prefills-----------------------------------------------------------------------------------------------------------------	
	public List<String> getTransportationDetails(TicketTO ticketTO) throws  MVCApplicationException
	{
		
		DBConnectionI db = new DBConnection();
		List<String> busSchedule = new ArrayList<String>();
		try
		{
			myConn = db.getMySQLConnection();
			
			pStmt = myConn.prepareStatement(QueryConstants.GET_SCHEDULE_INFORMATION);
			pStmt.setString(1, ticketTO.getStrJourneyDate());
			
			myRslt = pStmt.executeQuery();
			
			while(myRslt.next())
			{
				String scheduleID = myRslt.getString("s_id");			
				busSchedule.add(scheduleID);
			}
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException(e);
		}
		return busSchedule;
	}

	
	
	
	

	public List<BusTO> getBusDetails(String scheduleId) throws  MVCApplicationException 
	{
	
		DBConnectionI db = new DBConnection();
		List<BusTO> busDetails = new ArrayList<>();
		
		try
		{
			myConn = db.getMySQLConnection();
			
			pStmt = myConn.prepareStatement(QueryConstants.GET_BUS_INFORMATION);
			pStmt.setString(1, scheduleId);
			
			myRslt = pStmt.executeQuery();
			
			while(myRslt.next())
			{
				String busId = (String) myRslt.getString(1);
				String busName = (String) myRslt.getString(2);
				BusTO bus = new BusTO(busId, busName);
				busDetails.add(bus);
			}
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException(e);
		}
		
		return busDetails;
	}


	
	
	
	public List<String> getSeatsDetails(String scheduleId) throws MVCApplicationException 
	{
		DBConnectionI db = new DBConnection();
		List<String> seats = new ArrayList<>();
		try
		{
			myConn = db.getMySQLConnection();
			
			pStmt = myConn.prepareStatement(QueryConstants.GET_SEAT_INFORMATION);
			pStmt.setString(1, scheduleId);
			
			myRslt = pStmt.executeQuery();
			
			while(myRslt.next())
			{
				seats.add((String) myRslt.getString(1) );
			}
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException(e);
		}
		return seats;
	}

	
	
	
	
	

	public List<String> getScheduleTime(String scheduleId) throws MVCApplicationException 
	{
		
		DBConnectionI db = new DBConnection();
		List<String> time = new ArrayList<>();
		try
		{
			myConn = db.getMySQLConnection();
			
			pStmt = myConn.prepareStatement(QueryConstants.GET_TIME_INFORMATION);
			pStmt.setString(1, scheduleId);
			
			myRslt = pStmt.executeQuery();
			
			
			
			while(myRslt.next())
			{
				String scheduleTime = myRslt.getTime(1).toString();
				time.add(scheduleTime);
			}
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException(e);
		}
		
		return time;
			
	}


	
	
	
	
	public List<String> getCostDetails(TicketTO data) throws  MVCApplicationException 
	{
		
		DBConnectionI db = new DBConnection();
		List<String> costInfo = new ArrayList<>();
		
		try
		{
			myConn = db.getMySQLConnection();
			
			pStmt = myConn.prepareStatement(QueryConstants.GET_COST_INFORMATION);
			pStmt.setString(1, data.getFromCity());
			pStmt.setString(2, data.getToCity());
			
			myRslt = pStmt.executeQuery();
			
			
			while(myRslt.next())
			{
				String travelCost = myRslt.getString(1).toString();
				costInfo.add(travelCost);
			}
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException(e);
		}
		
		return costInfo;
	}


	
	//-----------------------------------------------------------------------------------------------------------------	-----------------------------------------------------------------------------------------------------------------	
	
	
	
	//Generate Ticket ID
	public String generateTicketID(String id) throws  MVCApplicationException 
	{
		DBConnectionI db = new DBConnection();
		
		
		try
		{
			myConn = db.getMySQLConnection();
			stmt = myConn.createStatement();
			myRslt = stmt.executeQuery(QueryConstants.GET_TICKET_ID);
		
			if(myRslt.next())
			{
				id = myRslt.getString("ticket_id");
			}
			
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException(e);
		}
		return id;
	}


	
	
	//Book Ticket
	public String bookTickets(TicketTO ticketTO) throws  MVCApplicationException 
	{
	
		DBConnectionI db = new DBConnection();
		
		try
		{
			myConn = db.getMySQLConnection();
			
			pStmt = myConn.prepareStatement(QueryConstants.BOOKTICKETS,Statement.RETURN_GENERATED_KEYS);
			pStmt.setString(1, ticketTO.getTicketID());
			pStmt.setString(2, ticketTO.getCustomer().getCustomerId());
			pStmt.setString(3, ticketTO.getFromCity());
			pStmt.setString(4, ticketTO.getToCity());
			pStmt.setDate(5, new Date(ticketTO.getJourneyDate().getTime()));
			pStmt.setInt(6, ticketTO.getNoOfTickets());
			pStmt.setString(7, ticketTO.getBus().getBusId());
			pStmt.setString(8, ticketTO.getTime());
			pStmt.setDouble(9, ticketTO.getCost());
			
			int n = pStmt.executeUpdate();
			myRslt = pStmt.getGeneratedKeys();
			
			if(myRslt.next())
			{
				ticketTO.setTicketID((String) myRslt.getString(1));
			}
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException(e);
		}
		
		return ticketTO.getTicketID();
		
		
	}


	
	//View Booked Ticket
	public TicketTO viewTicket(String ticketID) throws  MVCApplicationException 
	{
	
		DBConnectionI db = new DBConnection();
		TicketTO ticketTO =null;
		try
		{
			myConn = db.getMySQLConnection();
			
			pStmt = myConn.prepareStatement(QueryConstants.VIEWTICKET);
			pStmt.setString(1, ticketID);
			
			myRslt = pStmt.executeQuery();
			
			while(myRslt.next())
			{
				String customerID = myRslt.getString("customer_id");
				CustomerTO customerTO = new CustomerTO();
				customerTO.setCustomerId(customerID);
				
				String fromCity = myRslt.getString("location_from");
				String toCity = myRslt.getString("location_to");
				String strJourneyDate = myRslt.getDate("journey_date").toString();
				String strNoOfTickets = myRslt.getString("number_of_tickets");
				String busID = myRslt.getString("bus_id");
				BusTO bus = new BusTO();
				bus.setBusId(busID);
				String time =  myRslt.getTime("bus_time").toString();
				
				String ticketCharge = (String)myRslt.getString("ticket_charge");
				
				ticketTO = new TicketTO(customerTO, fromCity, toCity, strJourneyDate, bus, strNoOfTickets, time, ticketCharge);
				
			}
			
			if(ticketTO!=null)
			{
				ticketTO.setTicketID(ticketID);
			}
			
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException(e);
		}
		
		return ticketTO;
		
	}
	
	
	
}




/*import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.btrs.model.entity.TicketTO;
import com.btrs.service.constants.QueryConstants;
import com.btrs.service.util.DBConnection;
import com.btrs.service.util.DBConnectionI;


public class TicketDAO implements TicketDAOI
{

	
	static Connection myConn = null;
	static PreparedStatement pStmt = null;
	static ResultSet myRslt = null;
	
	
	
	
	
	
	
	public List<TicketTO> getCustomerTickets(String customerID) throws SQLException
	{
		
		
		DBConnectionI db = new DBConnection();
		myConn = db.getMySQLConnection();
		
		
		pStmt = myConn.prepareStatement(QueryConstants.CUSTOMER_RESERVED_TICKETS);
		pStmt.setString(1, customerID);
		
		
		myRslt = pStmt.executeQuery();
		
		List<TicketTO> customerTickets = new ArrayList<TicketTO>();
		while(myRslt.next())
		{
			
			TicketTO ticketTO = new TicketTO();
			
			ticketTO.setTicketID((String) myRslt.getString("ticket_id"));
			
			customerTickets.add(ticketTO);
		}
		
		
		return customerTickets;
		
	}
	
	
	
	
	
	
	public boolean cancelReservation(String ticketID) throws SQLException 
	{
		
		boolean cancelled = false;
		
		DBConnectionI db = new DBConnection();
		myConn = db.getMySQLConnection();
		int n=0;
			
				pStmt = myConn.prepareStatement(QueryConstants.CANCEL_RESERVED_TICKETS);
				pStmt.setString(1, ticketID);
				
	
		
		
		if(n==1)
			cancelled = true;
			
		return cancelled;
		
		
	}
}
*/

