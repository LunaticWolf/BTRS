package com.btrs.service.persistance.bo;

import java.sql.SQLException;

import com.btrs.model.entity.BusTO;
import com.btrs.service.exception.MVCApplicationException;

public interface BusBOI 
{

	public boolean validateBusEntry(BusTO busTO) throws   MVCApplicationException;
	
}
